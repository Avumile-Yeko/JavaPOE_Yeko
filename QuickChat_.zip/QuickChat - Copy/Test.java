package QuickChat;

public @interface Test {

}
